#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <time.h>
int won1 = 0, won2 = 0, games_played = 0, draw = 0;
char *plr1;
char *plr2;
char user = 'c';
int won_check = 0;

void delay(int number_of_seconds)
{
    // Converting time into milli_seconds
    int milli_seconds = 1000 * number_of_seconds;

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;
}
void plr_sign(void)
{
    printf("\n\n PLAYER %-10s ==> X \n\n PLAYER %-10s ==> O \n\nPress Enter to start!\n", plr1, plr2);
    getch();
}
char **game_frame(void)
{
    char **arr = (char **)calloc(3, sizeof(char *));
    for (int i = 0; i < 3; i++)
    {
        arr[i] = (char *)calloc(3, sizeof(char));
    }
    return arr;
}
void print_head(void)
{
    printf("*********************************************************************************************************************************\n********************************************************||TICK TACK TOE||********************************************************\n*********************************************************************************************************************************\n\n");
    print_won();
}
void print_rules(void)
{
    system("cls");
    print_head();
    printf("1)Two players challenge each other by using a 3x3 grid in Tic Tac Toe.\n\n2)One player chooses noughts(O) , the opposing player uses crosses(X).\n\n3)the first one to align 3 of their identical symbols, either noughts or crosses, (horizontally, vertically or diagonally) wins the game\n\n");
    printf("press enter to continue to the game:");
    getch();
    return;
}
void take_name(char *plr1, char *plr2)
{
    printf("Enter First player's name:");
    gets(plr1);
    printf("\nEnter second player's name:");
    gets(plr2);
    return;
}
void print_how(void)
{
    char alph = 97;
    printf("\n**players have to enter alphabets acordingly to  mark their sign \n");
    for (int i = 0; i <= 3; i++)
    {
        if (i == 0)
            putchar('\n');
        printf("==========\n");
        for (int j = 0; j < 3 && i < 3; j++)
        {
            if (j == 0)
                printf("%-1c", '|');
            printf("%-2c", alph++);
            printf("%-1c", '|');
            if (j == 2)
                putchar('\n');
        }
    }
    printf("\nPress Enter to continue!\n");
    getch();
    system("cls");
    return;
}
void input(char **frame, int plr)
{
    char sign = plr % 2 != 0 ? 'X' : 'O';
    int check = 1;
    while (check)
    {
        switch (getch())
        {
        case 'a':
        case 'A':
            if (frame[0][0] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[0][0] = sign;
                check = 0;
                break;
            }
        case 'b':
        case 'B':
            if (frame[0][1] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[0][1] = sign;
                check = 0;
                break;
            }
        case 'c':
        case 'C':
            if (frame[0][2] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[0][2] = sign;
                check = 0;
                break;
            }
        case 'd':
        case 'D':
            if (frame[1][0] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[1][0] = sign;
                check = 0;
                break;
            }
        case 'e':
        case 'E':
            if (frame[1][1] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[1][1] = sign;
                check = 0;
                break;
            }
        case 'f':
        case 'F':
            if (frame[1][2] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[1][2] = sign;
                check = 0;
                break;
            }
        case 'g':
        case 'G':
            if (frame[2][0] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[2][0] = sign;
                check = 0;
                break;
            }
        case 'h':
        case 'H':
            if (frame[2][1] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[2][1] = sign;
                check = 0;
                break;
            }
        case 'i':
        case 'I':
            if (frame[2][2] != 0)
            {
                printf("\ninvalid_input..\nTry again ! :");
                check = 1;
                break;
            }
            else
            {
                frame[2][2] = sign;
                check = 0;
                break;
            }
        default:
            printf("***Invalid input***\ntry again!");
            check = 1;
        }
    }
    return;
}
void print_inst(void)
{
    char alph = 97;
    printf("\nINDEX_!");
    for (int i = 0; i <= 3; i++)
    {
        if (i == 0)
            putchar('\n');
        printf("==========\n");
        for (int j = 0; j < 3 && i < 3; j++)
        {
            if (j == 0)
                printf("%-1c", '|');
            printf("%-2c", alph++);
            printf("%-1c", '|');
            if (j == 2)
                putchar('\n');
        }
    }
    printf("\n\n");
    return;
}
void print_updt(const char **updt)
{
    system("cls");
    print_head();
    print_inst();
    for (int i = 0; i < 3; i++)
    {
        printf("--------------\n");
        for (int j = 0; j < 3; j++)
        {
            if (j == 0)
                printf("|");
            printf("%3c|", (updt[i][j] == 0 ? ' ' : updt[i][j]));
        }
        printf("\n");
    }
    printf("--------------\n");
    puts("\n\n");
    return;
}
char check(const char **frame, int plr)
{
    char sign = plr % 2 != 0 ? 'X' : 'O';
    if (frame[0][0] == sign && frame[1][1] == sign && frame[2][2] == sign || frame[0][2] == sign && frame[1][1] == sign && frame[2][0] == sign)
        return sign;
    int cnt = 0;
    for (int i = 0; i < 3; i++)
    {
        cnt = 0;
        for (int j = 0; j < 3; j++)
        {
            cnt += frame[i][j] == sign ? 1 : 0;
        }
        if (cnt == 3)
            return sign;
    }
    for (int i = 0; i < 3; i++)
    {
        cnt = 0;
        for (int j = 0; j < 3; j++)
        {
            cnt += frame[j][i] == sign ? 1 : 0;
        }
        if (cnt == 3)
            return sign;
    }
    return 'N';
}
void anounce_winner(char chk, char *plr1, char *plr2)
{
    games_played++;
    if (chk == 'X')
        won1++;
    if (chk == 'O')
        won2++;
    printf("\n\t\t*************[%s WON :)]*************\n", chk == 'X' ? plr1 : plr2);
    delay(1.5);
    printf("\n\n             %s is a looser! looser!\n              na nana na naa....", chk == 'X' ? plr2 : plr1);
    getch();
    system("cls");
}
void print_won(void)
{
    if (won_check)
        printf("*%10s won: %d times\n*%10s won: %d times\n*%14s: %d times\n*  Games Played: %d times\n", plr1, won1, plr2, won2, "Draw", draw, games_played);
}

int main()
{

    do
    {
        system("cls");
        char **frame = (char **)calloc(3, sizeof(char *));
        for (int i = 0; i < 3; i++)
        {
            frame[i] = (char *)calloc(3, sizeof(char));
        }

        if (user == 'c' || user == 'C')
        {
            won1 = won2 = games_played = draw = 0;
            won_check = 0;
            print_head();
            printf("Enter 'R' to read rules or enter anything  to proceed further without reading rules:");
            switch (getch())
            {
            case 'r':
            case 'R':
                print_rules();
                break;
            default:
                break;
            }
            system("cls");
            print_head();
            free(plr1);
            free(plr2);
            plr1 = (char *)malloc(20 * sizeof(char));
            plr2 = (char *)malloc(20 * sizeof(char));
            take_name(plr1, plr2);
            won_check = 1;
            system("cls");
            print_head();
            print_how();
        }
        print_head();
        plr_sign();
        system("cls");

        char chk;
        int no_turns = 9;
        print_updt((const char **)frame);
        for (int i = 1; i <= no_turns; i++)
        {
            
            printf("> %s's turn : ", i % 2 == 0 ? plr2 : plr1);
            input(frame, i);
            print_updt((const char **)frame);
            chk = check(frame, i);
            if (chk == 'N')
                continue;
            else
            {
                anounce_winner(chk, plr1, plr2);
                break;
            }
        }
        if (chk == 'N')
        {
            games_played++;
            draw++;
            printf("\nits a Draw!\nNobody won..");
            printf("\nYou both (%s and %s) are loosers and winners\n", plr1, plr2);
        }
        delay(0.5);
        printf("\n\n1)Hit 'c' if you want play another game with differernt players\n2)Hit 0 to stop playing or any other button to continue to another game with same players\n");
        free(frame);
        user = getch();
    } while (user != '0');
    getch();
    return 0;
}